package gov.dhs.uscis.egis.eec.utils;

import java.io.BufferedReader;
import java.io.Reader;
import java.io.StringReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class StringExtraction {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public String extractCaseStatusUpdate (String xmlStr, String startTag, String endTag) {
		
		StringBuilder extractedData = new StringBuilder();
		try {
			Reader str = new StringReader(xmlStr);
			BufferedReader br = new BufferedReader(str);
			String line = br.readLine();
			
			int start = 0;
			int end = 0;
			while (line != null) {
				if (line.contains(startTag)) {
					extractedData.append(line + "\n");
					start++;
				}
				if (start > 0 && end < 1 && !line.contains(startTag)) {
					extractedData.append(line + "\n");
				}
				if (line.contains(endTag)) {
					end++;
				}
				line = br.readLine();
			}
			br.close();
		}
		catch (Exception e) {
			logger.error("Error: " + e.getLocalizedMessage(), e);
		}
		return extractedData.toString();
	}
}
