package gov.dhs.uscis.egis.eec.amq;

import java.io.File;
import java.util.Scanner;
import java.util.UUID;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;

public class MyAmqProducer {

	
	private static String url = "tcp://awe-egis-amq-dev-01.egis-dev.uscis.dhs.gov:61616";		//DT
	//private static String url = "tcp://awe-egis-amq-tst-01.egis-sint.uscis.dhs.gov:61616";	//SINT
	
	private static String queueName = "US.DHS.USCIS.EGIS.ESS.CSU.DATASHARE"; //"US.DHS.USCIS.EGIS.TSS.CSU.DataShare.Secured";				//listener
	//private static String queueName = "US.DHS.USCIS.EGIS.ESS.CSU.VIN.NOTIFICATION";			//sender
	//private static String queueName = "US.DHS.USCIS.EGIS.ESS.IVCS.CSU.STATUS.NOTIFICATION";	//sender
	
	//localhost
	//private static String url = "tcp://localhost:61616";					//localhost
	//private static String queueName = "CSU.DataShare.ESS.Secured";			//localhost queue
	
	
	private final static int DELIVERY_MODE = 2;
	private final static int PRIORITY = 4;
	private final static int EXPIRATION = 300000;
	private final static int DELIVERY_COUNT = 1;
	private final static String SOAP_ACTION = 
			"/CaseStatusUpdateNotification/ESB-CaseStatusUpdateNotificationServicePortTypeEndpoint/PublishCaseStatusUpdateNotification";
	
	public static void main(String[] args) throws JMSException {
		
		//messageConsumer();
		messageProducer();
		//System.out.println(readFile());
			
	}
	
	
	private static void messageProducer() throws JMSException {
		
		Connection connection = getConnection();
		Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Destination destination = session.createQueue(queueName);
		
		long currtime = System.currentTimeMillis();
		UUID uuid = UUID.randomUUID();
		
		for (int i = 1; i < 3; i++) {
			
			String str = readFile(i);
			MessageProducer producer = session.createProducer(destination);
			TextMessage message = session.createTextMessage(str);
			
			if (str.contains("DS-260")) {
				System.out.println("DS-260");
				message.setJMSType("DS-260");
			}
			else {
				System.out.println("IV Crossing");
				message.setJMSType("IV Crossing");
			}
			
			message.setJMSMessageID(message.getJMSMessageID());
			message.setJMSCorrelationID(uuid.toString());
			message.setJMSTimestamp(currtime);
			message.setJMSDeliveryMode(DELIVERY_MODE);
			message.setJMSPriority(PRIORITY);
			message.setJMSExpiration(EXPIRATION);
			message.setJMSDeliveryMode(message.getJMSDeliveryMode());
			message.setIntProperty("JMSXDeliveryCount", DELIVERY_COUNT);
			message.setStringProperty("SoapAction", SOAP_ACTION);
			
			producer.send(message);
		}
		
		connection.close();
	}
	
	private static void messageConsumer() throws JMSException {
		
		Connection connection = getConnection();
		connection.start();
		Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Destination destination = session.createQueue(queueName);
		
		MessageConsumer consumer = session.createConsumer(destination);
		Message message = consumer.receive();
		
		if (message instanceof TextMessage) {
			TextMessage textMessage = (TextMessage) message;
			System.out.println("Received message: \n" +textMessage.getText());
		}
		
		connection.close();
	}
	
	
	private static Connection getConnection() throws JMSException {
		ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
		Connection connection = connectionFactory.createConnection("USCIS-EGIS-ESS-USER","PlsChang3m3^");	//"USCIS-EGIS-ESS-USER","PlsChang3m3^"
		return connection;
	}
	
	private static String readFile(int i) {
		
		StringBuffer buffer = new StringBuffer();
		try {
			File myfile = new File("src/main/resources/sampleEMS-msg" +i);
			Scanner scanner = new Scanner(myfile);
			while (scanner.hasNextLine()) {
				String data = scanner.nextLine();
				buffer.append(data + "\n");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return buffer.toString();
	}
	
}
