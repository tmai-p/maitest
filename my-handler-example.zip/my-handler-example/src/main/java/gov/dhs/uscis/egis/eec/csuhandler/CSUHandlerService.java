package gov.dhs.uscis.egis.eec.csuhandler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class CSUHandlerService {

	private Logger logger = LoggerFactory.getLogger(CSUHandlerService.class);

	public String statusCheck() {
        logger.info("Checking service status");
		return "EssCsuHandler Running";
	}

}