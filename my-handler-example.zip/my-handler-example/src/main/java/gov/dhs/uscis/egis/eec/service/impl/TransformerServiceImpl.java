package gov.dhs.uscis.egis.eec.service.impl;

import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import gov.dhs.uscis.egis.eec.service.TransformerService;

/**
 * This class transform the CSU XML into the EVIP XML
 *
 */

@Service
public class TransformerServiceImpl implements TransformerService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired ResourceLoader resourceLoader;

	/* (non-Javadoc)
	 * @see gov.dhs.uscis.egis.eec.service.impl.TransformerService#convertToEVIP(java.lang.String, java.lang.String)
	 */
	public String convertToEVIP(String auditCorrID, String refStr, String inXMLString) {

		StreamResult outputXmlResult = null;
		String xmlString = null;
		Writer outputWriter = null;

		try {
			Resource resourceXslt = resourceLoader.getResource("classpath:xslt/CSU2EVIP.xsl");
			InputStream xslt = resourceXslt.getInputStream();
			StreamSource inputSource = new StreamSource(new StringReader(inXMLString));
			StreamSource styleSource = new StreamSource(xslt);
			Transformer transformer = TransformerFactory.newInstance().newTransformer(styleSource);

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
			String timestamp = sdf.format(new Date());
		    transformer.setParameter("timestamp", timestamp);

			outputWriter = new StringWriter();
			outputXmlResult = new StreamResult(outputWriter);
			transformer.transform(inputSource, outputXmlResult);
			xmlString = outputXmlResult.getWriter().toString();
		} catch (Exception e) {
			logger.error("Error: " +e.getMessage(), e);
		}

		return xmlString;
	}

}
