package gov.dhs.uscis.egis.eec.amq;

import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import gov.dhs.uscis.egis.eec.utils.ParseXmlWithXpath;

/**
 * 
 * @author tpmai
 * Validate the following:
 * i.  UseDVFilter=‘Y’
 * ii. DosCaseID DOES NOT CONTAIN pattern \d{4}[a-zA-Z]{2}\d{1,5}
 * 
 */
@Component
public class CaseValidation implements AmqConstants {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired ParseXmlWithXpath parse;
	
	@Value("${amq.jms.use-dv-filter}")
	private String useDVFilter;
	
	
	public boolean validatePattern(String xml) {
		boolean valid = false;
		
		if (useDVFilter.equals("Y") && !checkDosCaseIDPattern(xml)) {
			valid = true;
		}
		
		logger.info("validPattern found => " + useDVFilter + " " +valid);
		return valid;
	}
	
	private boolean checkDosCaseIDPattern(String xml) {
		boolean match = false;
		String caseId = parse.getCaseId(xml, CASEID_XPATH_EXPRESSION);
		
		if (!caseId.isEmpty()) {
			match = Pattern.matches(DV_PATTERN, caseId);
		}
		logger.info("checkDosCaseIDPattern => " +match);
		return match;
	}
	
}
