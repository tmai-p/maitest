package gov.dhs.uscis.egis.eec.amq;

/**
 * Constants used for the AMQ messages.
 *
 */
public interface AmqConstants {

	int DELIVERY_MODE = 2;
	String TYPE_IV = "IV Crossing";
	String TYPE_DS = "DS-260";
	int PRIORITY = 4;
	int EXPIRATION = 300000;
	int DELIVERY_COUNT = 1;
	
	String SOAP_ACTION = "/CaseStatusUpdateNotification/ESB-CaseStatusUpdateNotificationServicePortTypeEndpoint/PublishCaseStatusUpdateNotification";
	String ANUM_XPATH_EXPRESSION = "//Envelope/Body/CaseStatusUpdate/PersonCountryAssociation/AlienRole/AlienIDDetails/AlienNumber/IdentificationID";
	String CASEID_XPATH_EXPRESSION = "//Envelope/Body/CaseStatusUpdate/ActivityIdentification";
	String FNAME_XPATH_EXPRESSION = "//Envelope/Body/CaseStatusUpdate/Person/PersonName/PersonGivenName";	
	String LNAME_XPATH_EXPRESSION = "//Envelope/Body/CaseStatusUpdate/Person/PersonName/PersonSurName";	
	String CSUBODY_XPATH_EXPRESSION = "//Envelope/Body";
	
	String XML_START_TAG = ":CaseStatusUpdate";
	String XML_END_TAG = "CaseStatusUpdate>";

    //AMQ
	String MSG_KEY_JMS_LISTENER_FAILED = "message.amq.listener.failed";
    String MSG_KEY_JMS_LISTENER_SUCCESS = "message.amq.listener.success";
    String MSG_KEY_JMS_MESSAGE_INVALID = "message.amq.message.invalid";
    String MSG_KEY_JMS_SENDER_FAILED = "message.amq.sender.failed";
    String MSG_KEY_JMS_SENDER_SUCCESS = "message.amq.sender.success";
    String MSG_KEY_JMS_DIVERSITY_PATTERN = "message.datashare.diversity.message";

    
    //Case pattern validation
    final String DV_FILTER  = "Y";
	final String DV_PATTERN = "\\d{4}[a-zA-Z]{2}\\d{1,5}";	//example matched pattern "2018AF12528"
}
