package gov.dhs.uscis.egis.eec.amq;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import gov.dhs.uscis.egis.eec.service.impl.TransformerServiceImpl;
import gov.dhs.uscis.egis.eec.utils.ParseXmlWithXpath;
import gov.dhs.uscis.egis.eec.utils.StringExtraction;

@Component
public class ActiveMQJmsListener implements AmqConstants {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	ActiveMQJmsSender amqSender;
	@Autowired
	TransformerServiceImpl transformerService;
	@Autowired
	ParseXmlWithXpath parse;
	@Autowired
	CaseValidation caseValidation;
			
	@JmsListener(destination="${amq.jms.listener.queue-name}", containerFactory="jmsListenerFactory")
	public void receiveMessage (Message message) throws JMSException {
		
		String xmlBody = null;
		String auditCorrID = null;
		String anum = "", caseid = "", fname = "", lname = "", refStr = "", evipStr = "", csuBody = "";

		logger.info("JMS Listener starts... ");

		if (message instanceof TextMessage) {
			try {
				TextMessage textMessage = (TextMessage) message;
				xmlBody = textMessage.getText();
				auditCorrID = message.getJMSCorrelationID();
				
				logger.info("Message received content size ==>  " + xmlBody.length());

				anum = parse.parseXml(xmlBody, ANUM_XPATH_EXPRESSION);
				fname = parse.parseXml(xmlBody, FNAME_XPATH_EXPRESSION);
				lname = parse.parseXml(xmlBody, LNAME_XPATH_EXPRESSION);
				caseid = parse.getCaseId(xmlBody, CASEID_XPATH_EXPRESSION);
				csuBody = parse.removeUnwanted(xmlBody);
				
				logger.info("csuBody textString value: \n" + csuBody);
				
				refStr = caseid + "/" + fname + "/" + lname + "/" + message.getJMSType(); // get refString

				//case pattern ID logic
				if (caseValidation.validatePattern(xmlBody)) {
					
					logger.info("Message type => " +message.getJMSType().toString());
					if (message.getJMSType().contains(TYPE_IV)) {
						logger.info("convert to EVIP");
						evipStr = transformerService.convertToEVIP(auditCorrID, refStr, xmlBody);
						amqSender.sendMessageToAMQ(auditCorrID, csuBody, refStr);
						logger.info("call storedprocedure for DOSResponse \n ");
					}
					else {
						amqSender.sendMessageToAMQ(auditCorrID, csuBody, refStr);
					}
				}
				else {
					logger.info("Invalid pattern: AuditLogging => " + refStr);
				}
			} catch (JMSException e) {
				logger.error(e.getMessage());
			}
		} else {
			logger.error("message instance error");
		}
		logger.info("----- Listener per message done -----");
	}
}
