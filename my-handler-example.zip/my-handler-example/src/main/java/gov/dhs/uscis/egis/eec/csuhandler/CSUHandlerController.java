package gov.dhs.uscis.egis.eec.csuhandler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/CSUHandler")
public class CSUHandlerController {

    private CSUHandlerService csuHandlerService;

    @Autowired
    public CSUHandlerController(CSUHandlerService sampleService) {
        this.csuHandlerService = sampleService;
    }

    @GetMapping(produces = "text/plain; charset=utf-8")
    public ResponseEntity<String> serviceCheck() {
        String message = csuHandlerService.statusCheck();

        return ResponseEntity.status(HttpStatus.OK).body(message);
    }
}