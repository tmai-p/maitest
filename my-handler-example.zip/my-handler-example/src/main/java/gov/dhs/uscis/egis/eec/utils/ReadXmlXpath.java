package gov.dhs.uscis.egis.eec.utils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Node;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ReadXmlXpath {

	private static Logger logger = LoggerFactory.getLogger(ReadXmlXpath.class);
	
	public static void main(String[] args) throws Exception {
		
		//System.out.println(processDocument());
		getNodeList(getString());
		
	}
	
	public static String getNodeList(String xml) {
		try {
			Document doc = getXmlDocument(xml);
			doc.getDocumentElement().normalize();
			XPath xPath =  XPathFactory.newInstance().newXPath();
			XPathExpression expr = xPath.compile("//Envelope/Body/CaseStatusUpdate");
			Object ob = expr.evaluate(doc, XPathConstants.NODESET);
			
			//Object ob = (NodeList) xPath.compile(xpression).evaluate(doc, XPathConstants.NODESET);
			NodeList list = (NodeList)ob;
			System.out.println(list.getLength());
			
			for (int i = 0; i < list.getLength(); i++) {
				org.w3c.dom.Node node = list.item(i);
				System.out.println(node);
			}
		}
		catch(Exception e) {
			logger.error("getCaseId Exception: " +e.getMessage()); 
		}
		return null;
	}
	
	private static Document getXmlDocument(String xml) {
		
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		Document xmlDocument = null;
		try {
		    builder = builderFactory.newDocumentBuilder();
		    xmlDocument = builder.parse(new ByteArrayInputStream(xml.getBytes()));
		}
		catch (Exception e) {
			logger.error("getXmlDocument Exception: " +e.getMessage());  
		}
		return xmlDocument;
	}

	private static DocumentBuilder documentBuilder() {
		DocumentBuilderFactory builderFactory =
		        DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		try {
		    builder = builderFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
		    e.printStackTrace();  
		}
		return builder;
	}
	
	private static String processDocument() throws SAXException, IOException {
		
		String xml = getString();
		DocumentBuilder builder = documentBuilder();
		Document xmlDocument = builder.parse(new ByteArrayInputStream(xml.getBytes()));
		
		XPath xPath =  XPathFactory.newInstance().newXPath();
		String expression = "//Envelope/"
				+ "Body/"
				+ "CaseStatusUpdate/"
				+ "PersonCountryAssociation/"
				+ "AlienRole/"
				+ "AlienIDDetails/"
				+ "AlienNumber/"
				+ "IdentificationID";
		
		String value = "not found";
		try {
			value = xPath.compile(expression).evaluate(xmlDocument);
		}
		catch(XPathExpressionException e) {
			e.printStackTrace();
		}
		return value;
	}
	
	
	private static String getString() {
		
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
				"<ns0:Envelope xmlns:ns0=\"http://www.w3.org/2003/05/soap-envelope\">\n" + 
				"    <ns0:Header>\n" + 
				"        <ns1:ServiceConsumerData xmlns:ns1=\"http://uscis.gov/uscis/xsd/esb2/serviceauditingframework/2.0\">\n" + 
				"        	<ns1:ServiceRequestTimestamp>2020-08-21 14:15:02.039</ns1:ServiceRequestTimestamp>\n" + 
				"            <ns1:SourceSystem>USCIS ESB TSS DataShare-13.15</ns1:SourceSystem>\n" + 
				"            <ns1:AuditCorrelationID>b6682a0f-cb4a-4e7b-9385-18ae6d2afff6</ns1:AuditCorrelationID>\n" + 
				"            <ns1:EndUserID>USCIS-IOESS-USER</ns1:EndUserID>\n" + 
				"            <ns1:AuthenticationID>USCIS-IOESS-USER</ns1:AuthenticationID> \n" + 
				"        </ns1:ServiceConsumerData>\n" + 
				"    </ns0:Header>\n" + 
				"    <ns0:Body>\n" + 
				"    	<pfx2:CaseStatusUpdate xmlns:eg=\"http://uscis.egis.tss.datashare.dhs.gov/saxon-extension\"\n" + 
				"                       xmlns:exsl=\"http://exslt.org/common\"\n" + 
				"                       xmlns:ns2=\"http://uscis.gov/uscis/xsd/services/lockbox/cdm/1.1\"\n" + 
				"                       xmlns:ns3=\"http://niem.gov/niem/niem-core/2.0\"\n" + 
				"                       xmlns:ns4=\"http://niem.gov/niem/structures/2.0\"\n" + 
				"                       xmlns:ns5=\"http://niem.gov/niem/domains/immigration/2.0\"\n" + 
				"                       xmlns:ns6=\"http://niem.gov/niem/domains/intelligence/2.0\"\n" + 
				"                       xmlns:pfx2=\"http://uscis.gov/uscis/xsd/esb/csu/exchange/1.0\"\n" + 
				"                       xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"\n" + 
				"                       xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" + 
				"   <ns3:ActivityIdentification>\n" + 
				"      <ns3:IdentificationID>2018AF10934</ns3:IdentificationID>\n" + 
				"      <ns3:IdentificationCategoryDescriptionText>IVIS_CASE_NUMBER</ns3:IdentificationCategoryDescriptionText>\n" + 
				"   </ns3:ActivityIdentification>\n" + 
				"   <ns3:ActivityIdentification>\n" + 
				"      <ns3:IdentificationID/>\n" + 
				"      <ns3:IdentificationCategoryDescriptionText>POST_SEQ_NUMBER</ns3:IdentificationCategoryDescriptionText>\n" + 
				"   </ns3:ActivityIdentification>\n" + 
				"   <ns3:ActivityIdentification>\n" + 
				"      <ns3:IdentificationID>01</ns3:IdentificationID>\n" + 
				"      <ns3:IdentificationCategoryDescriptionText>Receipt Sequence Number</ns3:IdentificationCategoryDescriptionText>\n" + 
				"   </ns3:ActivityIdentification>\n" + 
				"   <ns3:ActivityIdentification>\n" + 
				"      <ns3:IdentificationID>I2018AF10934</ns3:IdentificationID>\n" + 
				"      <ns3:IdentificationCategoryDescriptionText>IVACS CASE NUMBER</ns3:IdentificationCategoryDescriptionText>\n" + 
				"   </ns3:ActivityIdentification>\n" + 
				"   <ns3:ActivityIdentification>\n" + 
				"      <ns3:IdentificationID/>\n" + 
				"      <ns3:IdentificationCategoryDescriptionText>Receipt Number</ns3:IdentificationCategoryDescriptionText>\n" + 
				"   </ns3:ActivityIdentification>\n" + 
				"   <ns3:ActivityIdentification>\n" + 
				"      <ns3:IdentificationID>2018AF10934</ns3:IdentificationID>\n" + 
				"      <ns3:IdentificationCategoryDescriptionText>DOS CASE ID</ns3:IdentificationCategoryDescriptionText>\n" + 
				"   </ns3:ActivityIdentification>\n" + 
				"   <ns3:ActivityDateRange>\n" + 
				"      <ns3:StartDate>\n" + 
				"         <ns3:Date>2018-05-03</ns3:Date>\n" + 
				"      </ns3:StartDate>\n" + 
				"   </ns3:ActivityDateRange>\n" + 
				"   <ns3:ActivityStatus>\n" + 
				"      <ns3:StatusText>A</ns3:StatusText>\n" + 
				"      <ns3:StatusDate>\n" + 
				"         <ns3:DateTime>2018-05-03T16:13:41</ns3:DateTime>\n" + 
				"      </ns3:StatusDate>\n" + 
				"      <ns3:StatusDescriptionText>Approved</ns3:StatusDescriptionText>\n" + 
				"      <ns3:StatusIssuerText>DoS</ns3:StatusIssuerText>\n" + 
				"   </ns3:ActivityStatus>\n" + 
				"   <ns3:ActivityStatus>\n" + 
				"      <ns3:StatusText>DETAILED</ns3:StatusText>\n" + 
				"      <ns3:StatusDescriptionText>IOE Case Status Update Type</ns3:StatusDescriptionText>\n" + 
				"   </ns3:ActivityStatus>\n" + 
				"   <ns2:Person ns4:id=\"APPLICANT\">\n" + 
				"      <ns3:PersonBirthDate/>\n" + 
				"      <ns3:PersonMaritalStatusText>M</ns3:PersonMaritalStatusText>\n" + 
				"      <ns2:PersonName ns3:personNameCommentText=\"LEGAL_NAME\">\n" + 
				"         <ns3:PersonGivenName>John   CHRISTIAN</ns3:PersonGivenName>\n" + 
				"         <ns3:PersonMiddleName/>\n" + 
				"         <ns3:PersonSurName>BOTON</ns3:PersonSurName>\n" + 
				"      </ns2:PersonName>\n" + 
				"      <ns2:PersonName ns3:personNameCommentText=\"ALIAS1_NAME\">\n" + 
				"         <ns3:PersonGivenName/>\n" + 
				"         <ns3:PersonMiddleName/>\n" + 
				"         <ns3:PersonSurName/>\n" + 
				"      </ns2:PersonName>\n" + 
				"      <ns2:PersonName ns3:personNameCommentText=\"ALIAS2_NAME\">\n" + 
				"         <ns3:PersonGivenName/>\n" + 
				"         <ns3:PersonMiddleName/>\n" + 
				"         <ns3:PersonSurName/>\n" + 
				"      </ns2:PersonName>\n" + 
				"      <ns3:PersonSexText>M</ns3:PersonSexText>\n" + 
				"      <ns3:PersonBirthLocation>\n" + 
				"         <ns3:LocationAddress>\n" + 
				"            <ns3:StructuredAddress>\n" + 
				"               <ns3:LocationCityName>AFFAME</ns3:LocationCityName>\n" + 
				"               <ns3:LocationCountyName/>\n" + 
				"               <ns3:LocationCountryName>BENIN</ns3:LocationCountryName>\n" + 
				"            </ns3:StructuredAddress>\n" + 
				"         </ns3:LocationAddress>\n" + 
				"      </ns3:PersonBirthLocation>\n" + 
				"      <ns2:PersonLimitedPeopleFromReligion/>\n" + 
				"   </ns2:Person>\n" + 
				"   <ns2:Person ns4:id=\"FATHER\">\n" + 
				"      <ns2:PersonName>\n" + 
				"         <ns3:PersonGivenName>SERAPHIN</ns3:PersonGivenName>\n" + 
				"         <ns3:PersonSurName>BOTON</ns3:PersonSurName>\n" + 
				"      </ns2:PersonName>\n" + 
				"   </ns2:Person>\n" + 
				"   <ns2:Person ns4:id=\"MOTHER\">\n" + 
				"      <ns2:PersonName>\n" + 
				"         <ns3:PersonGivenName>DANSI</ns3:PersonGivenName>\n" + 
				"         <ns3:PersonSurName>TOSSOU</ns3:PersonSurName>\n" + 
				"      </ns2:PersonName>\n" + 
				"   </ns2:Person>\n" + 
				"   <ns2:PersonCountryAssociation>\n" + 
				"      <ns2:AlienRole>\n" + 
				"         <ns2:RoleOfPartyReference ns4:ref=\"APPLICANT\"/>\n" + 
				"         <ns5:AlienIDDetails>\n" + 
				"            <ns5:AlienNumber>\n" + 
				"               <ns3:IdentificationID>066183918</ns3:IdentificationID>\n" + 
				"            </ns5:AlienNumber>\n" + 
				"         </ns5:AlienIDDetails>\n" + 
				"         <ns2:AlienCitizenship>\n" + 
				"            <ns2:CitizenshipLocation>\n" + 
				"               <ns3:StructuredAddress>\n" + 
				"                  <ns3:LocationCountryName>BENIN</ns3:LocationCountryName>\n" + 
				"               </ns3:StructuredAddress>\n" + 
				"            </ns2:CitizenshipLocation>\n" + 
				"         </ns2:AlienCitizenship>\n" + 
				"         <ns2:AlienImmigrationStatus>\n" + 
				"            <ns5:ImmigrationStatusCode>DV1</ns5:ImmigrationStatusCode>\n" + 
				"         </ns2:AlienImmigrationStatus>\n" + 
				"         <ns5:AdmissionIdentification>\n" + 
				"            <ns3:IdentificationCategoryDescriptionText xsi:nil=\"true\"/>\n" + 
				"            <ns3:IdentificationEffectiveDate/>\n" + 
				"            <ns3:IdentificationJurisdictionText/>\n" + 
				"         </ns5:AdmissionIdentification>\n" + 
				"      </ns2:AlienRole>\n" + 
				"      <ns3:LocationCountryName/>\n" + 
				"      <ns2:CountryOfChargeability>BENIN</ns2:CountryOfChargeability>\n" + 
				"   </ns2:PersonCountryAssociation>\n" + 
				"   <ns2:PartyContactAddressAssociation type=\"RESIDENCE\">\n" + 
				"      <ns2:PartyReference ns4:ref=\"APPLICANT\"/>\n" + 
				"      <ns2:ContactAddress>\n" + 
				"         <ns3:LocationAddress>\n" + 
				"            <ns3:StructuredAddress>\n" + 
				"               <ns3:LocationCityName/>\n" + 
				"               <ns3:LocationCountyName/>\n" + 
				"               <ns3:LocationCountryName>BENIN</ns3:LocationCountryName>\n" + 
				"            </ns3:StructuredAddress>\n" + 
				"         </ns3:LocationAddress>\n" + 
				"      </ns2:ContactAddress>\n" + 
				"   </ns2:PartyContactAddressAssociation>\n" + 
				"   <ns2:PartyContactAddressAssociation type=\"PHYSICAL\">\n" + 
				"      <ns2:PartyReference ns4:ref=\"APPLICANT\"/>\n" + 
				"      <ns2:ContactAddress>\n" + 
				"         <ns3:LocationAddress>\n" + 
				"            <ns3:StructuredAddress>\n" + 
				"               <ns3:AddressRecipientName>KPAHOSSOU TONTON VALENTIN</ns3:AddressRecipientName>\n" + 
				"               <ns3:LocationStreet>\n" + 
				"                  <ns3:StreetFullText>305 27 TH ST SW APT 6</ns3:StreetFullText>\n" + 
				"               </ns3:LocationStreet>\n" + 
				"               <ns3:LocationCityName>AUSTIN</ns3:LocationCityName>\n" + 
				"               <ns3:LocationStateName>MN</ns3:LocationStateName>\n" + 
				"               <ns3:LocationPostalCode>55912</ns3:LocationPostalCode>\n" + 
				"            </ns3:StructuredAddress>\n" + 
				"         </ns3:LocationAddress>\n" + 
				"      </ns2:ContactAddress>\n" + 
				"   </ns2:PartyContactAddressAssociation>\n" + 
				"   <ns2:PartyContactTelephoneAssociation>\n" + 
				"      <ns2:PartyReference ns4:ref=\"APPLICANT\"/>\n" + 
				"      <ns2:ContactTelephoneNumber>\n" + 
				"         <ns2:TelephoneNumber>\n" + 
				"            <ns3:FullTelephoneNumber>\n" + 
				"               <ns3:TelephoneNumberFullID>5075898372</ns3:TelephoneNumberFullID>\n" + 
				"            </ns3:FullTelephoneNumber>\n" + 
				"         </ns2:TelephoneNumber>\n" + 
				"      </ns2:ContactTelephoneNumber>\n" + 
				"   </ns2:PartyContactTelephoneAssociation>\n" + 
				"   <ns2:PersonEmploymentAssociation ns4:id=\"APPLICANT_EMPLOYMENT\" party_employer_type=\"EMPLOYER\">\n" + 
				"      <ns2:GenericEmployeeRole>\n" + 
				"         <ns2:RoleOfPartyReference ns4:ref=\"APPLICANT\"/>\n" + 
				"         <ns3:EmployeeOccupationText>DOC</ns3:EmployeeOccupationText>\n" + 
				"         <ns2:LaborCertificationCode>T</ns2:LaborCertificationCode>\n" + 
				"      </ns2:GenericEmployeeRole>\n" + 
				"   </ns2:PersonEmploymentAssociation>\n" + 
				"   <ns2:PersonBenefitRole type=\"APPLICANT\">\n" + 
				"      <ns2:RoleOfPartyReference ns4:ref=\"APPLICANT\"/>\n" + 
				"   </ns2:PersonBenefitRole>\n" + 
				"   <ns2:ImmigrationBenefitTypeIVandAlienRegistration type=\"Immigrant VISA and Alien Registration\">\n" + 
				"      <ns3:ActivityCategoryText>DS-260</ns3:ActivityCategoryText>\n" + 
				"   </ns2:ImmigrationBenefitTypeIVandAlienRegistration>\n" + 
				"   <ns2:CardDocument>\n" + 
				"      <ns2:DocumentStatus>\n" + 
				"         <ns3:StatusIssuerIdentification>\n" + 
				"            <ns3:IdentificationEffectiveDate>\n" + 
				"               <ns3:DateTime>2018-05-03T16:13:41</ns3:DateTime>\n" + 
				"            </ns3:IdentificationEffectiveDate>\n" + 
				"            <ns3:IdentificationExpirationDate>\n" + 
				"               <ns3:Date>2018-10-17</ns3:Date>\n" + 
				"            </ns3:IdentificationExpirationDate>\n" + 
				"         </ns3:StatusIssuerIdentification>\n" + 
				"         <ns3:StatusIssuerText>COT</ns3:StatusIssuerText>\n" + 
				"      </ns2:DocumentStatus>\n" + 
				"      <ns3:AddressRecipientName/>\n" + 
				"   </ns2:CardDocument>\n" + 
				"   <ns2:ParentChildAssociation>\n" + 
				"      <ns2:ParentRole>\n" + 
				"         <ns2:RoleOfPartyReference ns4:ref=\"FATHER\"/>\n" + 
				"         <ns2:ParentCode>FATHER</ns2:ParentCode>\n" + 
				"      </ns2:ParentRole>\n" + 
				"      <ns2:OffspringRole>\n" + 
				"         <ns2:RoleOfPartyReference ns4:ref=\"APPLICANT\"/>\n" + 
				"      </ns2:OffspringRole>\n" + 
				"   </ns2:ParentChildAssociation>\n" + 
				"   <ns2:ParentChildAssociation>\n" + 
				"      <ns2:ParentRole>\n" + 
				"         <ns2:RoleOfPartyReference ns4:ref=\"MOTHER\"/>\n" + 
				"         <ns2:ParentCode>MOTHER</ns2:ParentCode>\n" + 
				"      </ns2:ParentRole>\n" + 
				"      <ns2:OffspringRole>\n" + 
				"         <ns2:RoleOfPartyReference ns4:ref=\"APPLICANT\"/>\n" + 
				"      </ns2:OffspringRole>\n" + 
				"   </ns2:ParentChildAssociation>\n" + 
				"</pfx2:CaseStatusUpdate>\n" + 
				"\n" + 
				"    </ns0:Body>\n" + 
				"</ns0:Envelope>\n" + 
				"\n" + 
				"";
	}
}
