package gov.dhs.uscis.egis.eec.amq;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

@Component
public class CsuMessageCreator implements MessageCreator, AmqConstants {

	private String message;
	private String uuid;

	public Message createMessage(Session session) throws JMSException {
		
		TextMessage msg = session.createTextMessage(this.message);
		msg.setJMSMessageID(this.uuid);
		msg.setJMSTimestamp(System.currentTimeMillis());
		msg.setJMSDeliveryMode(DELIVERY_MODE);
		msg.setJMSCorrelationID(this.uuid);

		if (message.contains(TYPE_DS)) {
			msg.setJMSType(TYPE_DS);
		} else {
			msg.setJMSType(TYPE_IV);
		}
		msg.setJMSPriority(PRIORITY);
		msg.setJMSExpiration(EXPIRATION);
		msg.setIntProperty("JMSXDeliveryCount", DELIVERY_COUNT);
		msg.setStringProperty("SoapAction", SOAP_ACTION);
		msg.setStringProperty("requiresReply", "no");
	
		return msg;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

}
