package gov.dhs.uscis.egis.eec.utils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class DVFilter {

	final static String DV_FILTER = "DVFilter/UseDVFilter)='Y'";
	final static String DV_PATTERN = "\\d{4}[a-zA-Z]{2}\\d{1,5}";
	
	final static String P1 = "\\d{4}[a-zA-Z]{2}";
	final static String P2 = "\\d{1,5}";
	
	static ParseXmlWithXpath parse = new ParseXmlWithXpath();
	
	public static void main(String[] args) throws IOException {
		
		/*
		String p1 = "2020AB";  	
		String p2 = "12345";
		String dvPattern = "2018AF12528";
		
		DVFilter dvfilter = new DVFilter();
		
		String exp_ID = "//Envelope/Body/CaseStatusUpdate/ActivityIdentification";
		List<String> nodeValues_id = DVFilter.getNodes(readFile(), exp_ID);
		
		for (int i = 0; i < nodeValues_id.size(); i++) {
			String value = nodeValues_id.get(i);
			System.out.println(value);
			boolean match = Pattern.matches(DV_PATTERN, value);
			if (match) {
				//System.out.println("pattern matches: " +match);
				//break;
			}
		}
		*/
		
		Reader str = new StringReader(readFile());
		BufferedReader br = new BufferedReader(str);
		String line = br.readLine();
		
		int start = 0;
		int end = 0;
		while (line != null) {
			if (line.contains(":CaseStatusUpdate")) {
				System.out.println(line);
				start++;
			}
			if (start > 0 && end < 1 && !line.contains(":CaseStatusUpdate")) {
				System.out.println(line);
			}
			if (line.contains("CaseStatusUpdate>")) {
				end++;
			}
			line = br.readLine();
		}
		br.close();
	}
	
	
	private static List<String> getNodes(String xml, String xpression) {
		
		List<String> nodeValueList = new ArrayList<String>();
		String str = "";
		
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			
			Document doc = docBuilder.parse(new ByteArrayInputStream(xml.getBytes()));
			doc.getDocumentElement().normalize();
			
			XPath xpath = XPathFactory.newInstance().newXPath();
			
			NodeList nodelist = (NodeList) xpath.compile(xpression).evaluate(doc, XPathConstants.NODESET);
			System.out.println("nodelist: " +nodelist.getLength());
			
			
			for (int i = 0; i < nodelist.getLength(); i++) {
				//nodeValueList.add(nodelist.item(i).getChildNodes());
				
				if (nodelist.item(i).getTextContent().contains("DOS")) {
					//System.out.println(i + " " +nodelist.item(i).getTextContent());
					str = nodelist.item(i).getTextContent().trim();
				}
			}
			System.out.println(str);
			int endIndex = str.indexOf(" ");
			System.out.println(str.substring(0, endIndex));
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return nodeValueList;
	}
	
	
	
	/*
	 * Read a file from /resources
	 */
	@SuppressWarnings("resource")
	private static String readFile() {
		
		StringBuffer buffer = new StringBuffer();
		try {
			File myfile = new File("src/main/resources/sampleEMS-msg1");
			Scanner scanner = new Scanner(myfile);
			while (scanner.hasNextLine()) {
				String data = scanner.nextLine();
				buffer.append(data + "\n");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return buffer.toString();
	}
}
