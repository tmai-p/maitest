package gov.dhs.uscis.egis.eec.config;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;

@Configuration
public class ActiveMQJmsConfig {
	
	@Value("${amq.jms.broker-url}")
	private String BROKER_URL;
	
	@Value("${amq.jms.broker-username}")
	private String BROKER_USERNAME;
	
	@Value("${amq.jms.broker-password}")
	private String BROKER_PASSWORD;
	
	@Bean
	public ActiveMQConnectionFactory connectionFactory() {
		ActiveMQConnectionFactory conn = new ActiveMQConnectionFactory();
		conn.setBrokerURL(BROKER_URL);
		conn.setUserName(BROKER_USERNAME);
		conn.setPassword(BROKER_PASSWORD);
		return conn;
	}
	
	@Bean
	public CachingConnectionFactory cacheFactory() {
		CachingConnectionFactory cacheConnectionFactory = new CachingConnectionFactory(connectionFactory());
		cacheConnectionFactory.setSessionCacheSize(10);
		return cacheConnectionFactory;
	}
	
	@Bean
	public JmsTemplate jsmTemplate() {
		return new JmsTemplate(cacheFactory());
	}
	
	@Bean
	public DefaultJmsListenerContainerFactory jmsListenerFactory() {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		//factory.setConnectionFactory(connectionFactory());
		factory.setConnectionFactory(connectionFactory());
		//factory.setRecoveryInterval(30 * 1000L);
		factory.setConcurrency("1-3");
		return factory;
	}
}
