package gov.dhs.uscis.egis.eec.service;

/**
 * This interface defines the behavior of the transformer service.
 */

public interface TransformerService {

	/**
	 * This class convert the input CSU XML to the EVIP XML.
	 * 
	 * @param auditCorrID
	 * @param inXMLString
	 * @return
	 */
	String convertToEVIP(String auditCorrID, String refStr, String inXMLString);
}
