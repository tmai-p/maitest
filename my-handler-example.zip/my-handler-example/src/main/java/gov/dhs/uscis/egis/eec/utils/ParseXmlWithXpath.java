package gov.dhs.uscis.egis.eec.utils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

@Component
public class ParseXmlWithXpath {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public String parseXml (String xml, String xpression) {
		String parsedValue = null;
		try {
			parsedValue = processDocument(xml, xpression);
		} catch (SAXException e) {
			logger.error("SAXException: " +e.getMessage());
		} catch (IOException e) {
			logger.error("IOException: " +e.getMessage());
		}
		return parsedValue;
	}
	
	public String removeUnwanted(String xmlStr) {
		
		String resultOut = "";
		try {
			Document documentIn = getXmlDocument(xmlStr);

			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document documentOut = documentBuilder.newDocument();

			NodeList nodeList = documentIn.getElementsByTagName("pfx2:CaseStatusUpdate");
			Element element = (Element) nodeList.item(0);
			Node childNode = documentOut.importNode(element, true);

			documentOut.appendChild(childNode);

			Transformer tf = TransformerFactory.newInstance().newTransformer();
			tf.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			tf.setOutputProperty(OutputKeys.INDENT, "yes");
			Writer writer = new StringWriter();
			tf.transform(new DOMSource(documentOut), new StreamResult(writer));
			resultOut = writer.toString();
		}
		catch(Exception e) {
			logger.error("removeUnwanted Exception: " +e.getMessage()); 
		}
		return resultOut;
	}
	
	public String getNodeList(String xml) {
		try {
			Document doc = getXmlDocument(xml);
			doc.getDocumentElement().normalize();
			XPath xPath =  XPathFactory.newInstance().newXPath();
			String xpression = "//Envelope/Body";
			NodeList nodelist = (NodeList) xPath.compile(xpression).evaluate(doc, XPathConstants.NODESET);
			for (int i = 0; i < nodelist.getLength(); i++) {
				System.out.println(nodelist.item(i));
			}
		}
		catch(Exception e) {
			logger.error("getCaseId Exception: " +e.getMessage()); 
		}
		return null;
	}
	
	public String getCaseId(String xml, String xpression) {
		
		String caseId = "";
		try {
			Document doc = getXmlDocument(xml);
			doc.getDocumentElement().normalize();
			XPath xPath =  XPathFactory.newInstance().newXPath();
			NodeList nodelist = (NodeList) xPath.compile(xpression).evaluate(doc, XPathConstants.NODESET);
			
			for (int i = 0; i < nodelist.getLength(); i++) {
				if (nodelist.item(i).getTextContent().contains("DOS")) {
					//System.out.println(i + " " +nodelist.item(i).getTextContent());
					caseId = nodelist.item(i).getTextContent().trim();
					if (!caseId.isEmpty()) {
						int endIndex = caseId.indexOf(" ");
						caseId = caseId.substring(0, endIndex);		//Strip out the description
					}
				}
			}
		}
		catch(Exception e) {
			logger.error("getCaseId Exception: " +e.getMessage()); 
		}
		return caseId.trim();
	}

	/*
	public DocumentBuilder documentBuilder() {
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		try {
		    builder = builderFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			logger.error("ParseConfigurationException: " +e.getMessage()); 
		}
		return builder;
	}
	*/
	
	private Document getXmlDocument(String xml) {
		
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		Document xmlDocument = null;
		try {
		    builder = builderFactory.newDocumentBuilder();
		    xmlDocument = builder.parse(new ByteArrayInputStream(xml.getBytes()));
		}
		catch (Exception e) {
			logger.error("getXmlDocument Exception: " +e.getMessage());  
		}
		return xmlDocument;
	}

	private String processDocument(String xml, String xpathExpression) throws SAXException, IOException {
		
		Document xmlDocument = getXmlDocument(xml);
		XPath xPath =  XPathFactory.newInstance().newXPath();
		String value = "not found";
		
		try {
			value = xPath.compile(xpathExpression).evaluate(xmlDocument);
		}
		catch(XPathExpressionException e) {
			logger.error("XpathExpression: " +e.getMessage());
		}
		return value;
	}

}
