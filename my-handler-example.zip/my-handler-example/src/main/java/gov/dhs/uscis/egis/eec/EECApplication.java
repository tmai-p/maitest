package gov.dhs.uscis.egis.eec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class EECApplication {

	public static void main(String[] args) {
		SpringApplication.run(EECApplication.class, args);
	}

}