package gov.dhs.uscis.egis.eec.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Pattern;

public class EnvirVariable {

	
	final static String DV_PATTERN = "\\d{4}[a-zA-Z]{2}\\d{1,5}";
	
	public static void main(String[] args) {
		
		//String value = "2018AF125281";
		String value = "ABD2019662011";
		
		boolean match = Pattern.matches(DV_PATTERN, value);
		System.out.println("pattern matches: " +match);
		
		
		/*
		Map<?,?> map = new HashMap<>();
		map = System.getenv();
		
		for (Entry<?,?> entry : map.entrySet()) {
			System.out.println("key: " +entry.getKey() +" = " +entry.getValue());
		}
		*/
	}
}
