package gov.dhs.uscis.egis.eec.amq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

/**
 * This class send the CSU message to the IVCS queue.
 */
@Service
public class ActiveMQJmsSender implements AmqConstants {
	
	@Autowired
	JmsTemplate jmsTemplate;
	@Autowired
	CsuMessageCreator csuMessageCreator;

	@Value("${amq.jms.ds.queue-name}")
	private String destinationQueue_DS;

	@Value("${amq.jms.iv.queue-name}")
	private String destinationQueue_IV;

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * Send the message to the IVCS Queue for down stream processing.
	 * 
	 * @param corrId
	 * @param strMessage
	 */
	public void sendMessageToAMQ(String corrId, String strMessage, String ref) {

		String queueName = "";
		try {
			csuMessageCreator.setMessage(strMessage);
			csuMessageCreator.setUuid(corrId);
			
			if (strMessage.contains(TYPE_DS)) {
				queueName = this.destinationQueue_DS;
			} else {
				queueName = this.destinationQueue_IV;
			}
			long begin = System.currentTimeMillis();
			jmsTemplate.send(queueName, csuMessageCreator);
			long end = System.currentTimeMillis();
			long result = end - begin;
			logger.info("Result Time ======> " +result);
		} catch (Exception e) {
			logger.error("ERROR: auditLogging => " +e.getMessage(), e);
		}
	}
}
