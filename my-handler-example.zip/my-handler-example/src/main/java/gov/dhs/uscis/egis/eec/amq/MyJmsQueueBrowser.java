package gov.dhs.uscis.egis.eec.amq;

import java.util.Enumeration;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;

public class MyJmsQueueBrowser {

	//Localhost
	//private static final String SERVER_NAME = "tcp://localhost:61616";
	//private static final String QUEUE_NAME = "DataShare.ESS.Secured";
	
	
	//DT envir
	private static String SERVER_NAME = "tcp://awe-egis-amq-dev-01.egis-dev.uscis.dhs.gov:61616";
	
	//RT
	//private static String SERVER_NAME = "tcp://awe-egis-amq-tst-01.egis-sint.uscis.dhs.gov:61616";
	
	//*****************************/
	
	//Listening Queue
	private static final String QUEUE_DATASHARE_DT = "US.DHS.USCIS.EGIS.ESS.CSU.DATASHARE" ; 	//"US.DHS.USCIS.EGIS.TSS.CSU.DataShare.ESS.Secured";
	private static final String QUEUE_DATASHARE_RT = "US.DHS.USCIS.EGIS.TSS.CSU.DataShare.Secured";
	
	//IV Queue
	private static final String QUEUE_IV = "US.DHS.USCIS.EGIS.ESS.CSU.VIN.NOTIFICATION";
	
	//DS Queue
	private static final String QUEUE_DS = "US.DHS.USCIS.EGIS.ESS.IVCS.CSU.STATUS.NOTIFICATION";
	
	
	
	/*
	 * MAIN
	 */
	public static void main(String[] args) throws JMSException {
		
		Connection connection = null;
		int sizeIV = 0;
		int sizeDS = 0;
		int sizeDOS = 0;
		int sizeDatashareDT = 0;
		int sizeDatashareRT = 0;
		
		try {
			ConnectionFactory connFactory = new ActiveMQConnectionFactory(SERVER_NAME);
			connection = connFactory.createConnection("USCIS-EGIS-ESS-USER","PlsChang3m3^");
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			
			Queue listenerQueueDT = null;
			Queue listenerQueueRT = null;
					
			if (SERVER_NAME.contains("dev-01")) {
				listenerQueueDT = session.createQueue(QUEUE_DATASHARE_DT);
			}
			else {
				listenerQueueRT = session.createQueue(QUEUE_DATASHARE_RT);
			}
			
			Queue queueIV = session.createQueue(QUEUE_IV);
			Queue queueDS = session.createQueue(QUEUE_DS);
			//Queue queueDOS = session.createQueue(QUEUE_DOS);
			connection.start();
			
			if (SERVER_NAME.contains("dev-01")) {
				sizeDatashareDT = messageBrowser(session, listenerQueueDT);
			}
			else {
				sizeDatashareRT = messageBrowser(session, listenerQueueRT);
			}
			
			sizeIV = messageBrowser(session, queueIV);
			sizeDS = messageBrowser(session, queueDS);
			//sizeDOS = messageBrowser(session, queueDOS);
			session.close();
		}
		finally {
			if (connection != null) {
				connection.close();
			}
		}
		
		System.out.println("");
		if (SERVER_NAME.contains("dev-01")) {
			System.out.println("DT AMQ");
			System.out.println("");
			System.out.println("** Listener Queue: " + QUEUE_DATASHARE_DT + "\t [" + sizeDatashareDT + "]");
		}
		else {
			System.out.println("RT AMQ");
			System.out.println("");
			System.out.println("** Listener Queue: " + QUEUE_DATASHARE_RT + "\t [" + sizeDatashareRT + "]");
		}
		
		System.out.println("");
		System.out.println("** IV Crossing Queue: " + QUEUE_IV + "\t [" + sizeIV + "]");
		System.out.println("");
		System.out.println("** DS-260 Queue: " + QUEUE_DS + "\t [" + sizeDS + "]");
		System.out.println("");
		//System.out.println("** DOS Queue: " + QUEUE_DOS + "\t [" + sizeDOS + "]");
		//System.out.println("");
	}
	
	private static int messageBrowser(Session sess, Queue queue) {
		int i = 0;
		try {
			System.out.println("Browsing through the queue...");
			QueueBrowser browser = sess.createBrowser(queue);
			Enumeration<?> item = browser.getEnumeration();
			
			while(item.hasMoreElements()) {
				item.nextElement();
				//TextMessage tm = (TextMessage) item.nextElement();
				//System.out.println("Browse : " + tm.getText());
				i++;
			}
			browser.close();
		}
		catch(Exception e) {
			System.out.println("Exeption [messageBrowser]: " +e.getStackTrace());
		}
		return i;
	}
	
	private static void messageProducer(Session sess, Queue queue) {
		try {
			MessageProducer producer = sess.createProducer(queue);
			
			String message = "Message";
			for (int i=0; i< 5; i++) {
				String payload = message + i;
				Message msg = sess.createTextMessage(payload);
				System.out.println("Sending text: " +payload);
				producer.send(msg);
			}
		}
		catch(Exception e) {
			System.out.println("Exeption [messageProducer]: " +e.getStackTrace());
		}
	}

}
